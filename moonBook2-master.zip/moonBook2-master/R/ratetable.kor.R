#' ratetable to calculated expected survival rate of Korean
#'
#' ratetable.kor
#'
#'  @format A ratetable for Korean population 1997-2014
"ratetable.kor"
