library(testthat)
library(moonBook2)

test_check("moonBook2")
