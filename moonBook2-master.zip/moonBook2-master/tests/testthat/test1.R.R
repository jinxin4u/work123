require(moonBook)
require(moonBook2)
require(ggplot2)
require(ggiraph)

ggSpine(acs,"Dx","smoking")

